
/*Creates a Sample Dataset to test the Database with*/

INSERT INTO `Entrepeneur` (`Ent_First_Name`, `Ent_Last_Name`, `Ent_SSN`, `Ent_Sex`, `Ent_DOB`, `Ent_Join`, `Ent_Password`) VALUES

("RJ", "Yang", 123456788, 'M', STR_TO_DATE('12/19/1995', '%m/%d/%Y'), STR_TO_DATE('04/13/2018', '%m/%d/%Y'), "admin1234"),

("William", "Wolfe", 123456787, 'M', STR_TO_DATE('09/11/1996', '%m/%d/%Y'), STR_TO_DATE('03/14/2018', '%m/%d/%Y'), "admin123"),

("Srihari", "Yenamandra", 123456786, 'M', STR_TO_DATE('09/12/1997', '%m/%d/%Y'), STR_TO_DATE('04/14/2017', '%m/%d/%Y'), "12admin34"),

("Arjun", "Yenamandra", 123456786, 'M', STR_TO_DATE('09/12/1997', '%m/%d/%Y'), STR_TO_DATE('04/14/2017', '%m/%d/%Y'), "12admin34"),

("Bob", "Yenamandra", 123456786, 'M', STR_TO_DATE('09/12/1997', '%m/%d/%Y'), STR_TO_DATE('04/14/2017', '%m/%d/%Y'), "12admin34");


INSERT INTO `Venture` (Entrepeneur_idEntrepeneur, IsDebt, MaxUnits, RemainUnits, PricePerUnit, StartDate, EndDate) VALUES

(5, 1, 4, 3, 29.6, STR_TO_DATE('04/13/2018', '%m/%d/%Y'), STR_TO_DATE('04/17/2018', '%m/%d/%Y'));

INSERT INTO `DebtVenture` (Venture_idVenture, `InterestRate`, ExpiryDate, `Guarantee`, PercentReturned) VALUES
(last_insert_id(), .06, STR_TO_DATE('04/13/2019', '%m/%d/%Y') , .3, 1);

INSERT INTO `Venture` (Entrepeneur_idEntrepeneur, IsDebt, MaxUnits, RemainUnits, PricePerUnit, StartDate, EndDate) VALUES

(3, 1, 20, 10, 4.01, STR_TO_DATE('04/13/2018', '%m/%d/%Y'), STR_TO_DATE('04/17/2018', '%m/%d/%Y'));

INSERT INTO `DebtVenture` (Venture_idVenture, `InterestRate`, ExpiryDate, `Guarantee`, PercentReturned) VALUES
(last_insert_id(), .04, STR_TO_DATE('04/13/2019', '%m/%d/%Y') , .2, .9);

INSERT INTO `Venture` (Entrepeneur_idEntrepeneur, IsDebt, MaxUnits, RemainUnits, PricePerUnit, StartDate, EndDate) VALUES

(1, 0, 60, 48, 19, STR_TO_DATE('04/13/2016', '%m/%d/%Y'), STR_TO_DATE('04/17/2017', '%m/%d/%Y'));

INSERT INTO `EqVenture` (Venture_idVenture, `PPS Initial`, ExpectedReturn, `PPS Now`)

VALUES
(last_insert_id(), 7.8, .05, 8.2);

INSERT INTO `Venture` (Entrepeneur_idEntrepeneur, IsDebt, MaxUnits, RemainUnits, PricePerUnit, StartDate, EndDate) VALUES
(1, 0, 20, 0, 7.8, STR_TO_DATE('04/13/2017', '%m/%d/%Y'), STR_TO_DATE('04/17/2017', '%m/%d/%Y'));

INSERT INTO `EqVenture` (Venture_idVenture, `PPS Initial`, ExpectedReturn, `PPS Now`)

VALUES
(last_insert_id(), 7.9, .03, 8.5);

INSERT INTO Individual (Ind_First_Name, Ind_Last_Name, Ind_Email, Ind_SSN, Ind_DOB, Ind_Join) VALUES

("Dev","Jhaveri", "email", "12345" , STR_TO_DATE('02/07/1997', '%m/%d/%Y'), current_date()),

("Clark","Kent", "email", "1234" , STR_TO_DATE('01/06/1997', '%m/%d/%Y'), current_date()),

("Bruce","Wayne", "email", "123" , STR_TO_DATE('08/05/1994', '%m/%d/%Y'), current_date());

INSERT INTO Corporation (CorporationName, CorporationDescrip) VALUES

("Amazon", "Amazon.com"),

("Old McDonald's Farm", "Old McDonald Had a Farm E-I-E-I-O"),

("Galactic Trade Confederation", "Angry about Taxes");

INSERT INTO IndRelationship(Individual_idIndividual, Venture_idVenture, IndReview, UnitsOwned, MonetaryValue) VALUES

(2, 1, 7, 6, 60),

(3, 1, 8, 3, 30),

(1, 2, 6, 10, 100),

(3, 2, 9, 10, 100), 

(2, 3 ,7, 2, 118), 

(1, 4, 5, 5, 25),

(2, 4, 8, 10, 50), 

(3, 4, 1, 1, 5);

INSERT INTO CorpRelationship(Venture_idVenture, Corporation_idCorporation, `CorpReview`) VALUES

(1, 1, 8),

(1, 2, 9),

(2, 1, 5),

(2, 3, 10),

(3, 2, 2),

(3, 3, 7),

(3, 1, 5), 

(4, 1, 8); 





