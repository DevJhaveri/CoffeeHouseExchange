package Models;

public class Const {
    public static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
    public static final String DB_URL = "jdbc:mysql://13.90.229.99/mydb";

    //  Database credentials
    public static final String USER = "willyadmin";
    public static final String PASS = "admin1234";


}
