package Models;

public class EntReq {
    int id;
    public EntReq() {
    }

    public EntReq(int id) {
        this.id = id;
    }

    public int getId() {

        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}
